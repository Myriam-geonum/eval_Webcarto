// Initialisation de la carte
var map = L.map('map');
var osmUrl = 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
var osmAttrib = 'Map data © OpenStreetMap contributors';
var osm = new L.TileLayer(osmUrl, { attribution: osmAttrib }).addTo(map);
map.setView([45.75, 4.85], 11); // Zoom sur le Grand Lyon 

/* Echelle à la carte, option n°1 */
L.control.scale({
    position: 'bottomright', /* Position de l'échelle en bas à droite */
    imperial: false,        /* pas en imperial pas nécessaire vue le périmètre d'étude mais intéressant à une échelle + grande*/
}).addTo(map);


/* récupération d'une donnée ponctuelle : sites de pluviométrie grace à fetch()  */
/* Définition de l'icône goutte bleue pour la donnée ponctuelle et changement au survol */

var goutteIcon = L.icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/5611/5611083.png', 
    iconSize: [20, 30], 
    iconAnchor: [10, 30], // Point d'ancrage (bas-centre de l'image) correspond au centre géographique, optionnel mais très utile; meilleure précision de l'icone 
    popupAnchor: [0, -30] // Position du popup par rapport à l'icône plus au moins au centre et plus ou moins éloigné
});

/* option n°5 qui consiste au survol de la donnée un changement, ici la taille est agrandie au survol */
/* création d'une deuxième variable similaire à la première mais avec une taille plus grande et ajustement des popup et ancrage */
var goutteIconLarge = L.icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/5611/5611083.png',
    iconSize: [30, 45], // Taille agrandie
    iconAnchor: [15, 45],
    popupAnchor: [0, -45]
});

// Création de la clusterisation 
var sitesPluieLayer = L.markerClusterGroup({
    disableClusteringAtZoom: 11,
    spiderfyOnMaxZoom: false,
    showCoverageOnHover: false,
    zoomToBoundsOnClick: true,
    maxClusterRadius: 90, 
    iconCreateFunction: function (cluster) {
        var childCount = cluster.getChildCount();
        if (childCount < 2) {
            return L.divIcon({ html: '', className: 'hidden-cluster' });
        }
        return L.divIcon({
            html: '<div><span>' + childCount + '</span></div>',
            className: 'marker-cluster marker-cluster-small',
            iconSize: new L.Point(40, 40)
        });
    }
});

// récupération avec fetch() + plusieurs fonctions lors du clic (zoom fluide et centré, popup, mise en place du buffer -- option n°5)
fetch('https://data.grandlyon.com/geoserver/metropole-de-lyon/ows?SERVICE=WFS&VERSION=2.0.0&request=GetFeature&typename=metropole-de-lyon:sites-de-pluviometrie&outputFormat=application/json&SRSNAME=EPSG:4171&sortBy=gid')
    .then(response => response.ok ? response.json() : Promise.reject(`Erreur HTTP: ${response.status}`))
    .then(data => {
        L.geoJson(data, {
            pointToLayer: (feature, latlng) => L.marker(latlng, { icon: goutteIcon }),
            onEachFeature: function (feature, layer) {
                var bufferCircle;
                layer.on({
                    mouseover: function () {
                        bufferCircle = L.circle(layer.getLatLng(), {
                            radius: 600,
                            color: '#1E90FF',
                            weight: 2,
                            fillColor: '#ADD8E6',
                            fillOpacity: 0.3
                        }).addTo(sitesPluieLayer);
                        layer.setIcon(goutteIconLarge);
                    },
                    mouseout: function () {
                        bufferCircle && sitesPluieLayer.removeLayer(bufferCircle);
                        layer.setIcon(goutteIcon);
                    },
                    click: function () {
                        var title = "Sites de Pluviométrie";
                        var content = "Les sites de pluviométrie jouent un rôle essentiel dans l'étude de la perméabilisation des sols. Ces sites sont utilisés pour mesurer la quantité de précipitations qui tombent sur un territoire donné, une donnée cruciale pour la gestion de l'eau et l'agriculture. En analysant ces données de précipitations, les experts peuvent mieux comprendre l'infiltration de l'eau dans le sol, un facteur clé pour évaluer la perméabilité des sols et la gestion des eaux de pluie. Cela permet également d'anticiper les risques d'inondation et de sécheresse, d'améliorer les pratiques agricoles et de mieux gérer les ressources en eau. ";
                        addInfoToBox(content, title);
                        map.flyTo(layer.getLatLng(), 12, {
                            duration: 1 // Durée de l'animation en secondes (facultatif, mais fluide)
                        });
                        layer.bindPopup(`
                            <strong>Nom du site :</strong> ${feature.properties.nom}<br>
                            <strong>Type :</strong> ${feature.properties.type}<br>
                            <strong>Altitude :</strong> ${feature.properties.zsol}
                        `).openPopup();
                    }
                });
            }
        }).addTo(sitesPluieLayer);
        map.addLayer(sitesPluieLayer);
    })
    .catch(error => console.error('Erreur lors du chargement des données GeoJSON :', error));


/* récupération d'une donnée polygonale : occupation du sol CLC */
// Fonction pour déterminer la couleur en fonction de la nomenclature

var CLCLayer = L.layerGroup();

function getColor(remark) {
    return remark === "Tissu urbain continu" ? '#E6004D' :
        remark === "Tissu urbain discontinu" ? '#FF0000' :
            remark === "Zones industrielles et commerciales" ? '#CC4DF2' :
                remark === "Réseaux routier et ferroviaire et espaces associés" ? '#CC0000' :
                    remark === "Zones portuaires" ? '#E6CCCC' :
                        remark === "Aéroports" ? '#E6CCE6' :
                            remark === "Espaces verts urbains" ? '#33CC33' :
                                remark === "Équipements sportifs et de loisirs" ? '#99FF99' :
                                    remark === "Extraction de matériaux" ? '#B2B2B2' : 
                                        remark === "Systèmes culturaux et parcellaires complexes" ? '#FFD966' : 
                                            remark === "Surfaces essentiellement agricoles, interrompues par des espaces naturels importants" ? '#FFE699' : 
                                                remark === "Vergers et petits fruits" ? '#FFB266' : 
                                                    remark === "Prairies" ? '#99FF33' : 
                                                        remark === "Chantiers" ? '#D9D9D9' :
                                                            remark === "Forêts de feuillus" ? '#80FF00' :
                                                                remark === "Landes et broussailles" ? '#A6FF80' :
                                                                    remark === "Forêt et végétation arbustive en mutation" ? '#A6F200' :
                                                                        remark === "Cours et voies d'eau" ? '#00CCF2' :
                                                                            remark === "Plans d'eau" ? '#80F2E6' :
                                                                                '#FFEDA0';
}

// Fonction de style
function style(feature) {
    return {
        fillColor: getColor(feature.properties.remark),
        weight: 1,
        opacity: 0.3,
        color: 'white',
        dashArray: '3',
        fillOpacity: 0.7
    };
}

document.addEventListener('DOMContentLoaded', function () {
    var closeButton = document.getElementById('closeInfo');
    if (closeButton) {
        closeButton.addEventListener('click', function () {
            var infoBox = document.getElementById('infoBox');
            infoBox.style.display = 'none'; // Cacher la boîte d'information
        });
    } else {
        console.error("Le bouton 'Fermer' n'a pas été trouvé dans le DOM.");
    }
});


// Fonction onEachFeature pour ajouter les événements aux polygones (effets au survol, popup, infobox)
function onEachFeature(feature, layer) {
    layer.on({
        mouseover: function () {
            layer.setStyle({ weight: 3, color: 'grey', dashArray: '' });
        },
        mouseout: function () {
            layer.setStyle({ weight: 1, color: 'white', dashArray: '3' });
        },
        click: function () {

            // Mettre à jour la boîte d'information si la propriété "remark" existe
            if (feature.properties.remark) {
                var title = "Corine Land Cover (CLC) - Type de Revêtement";
                var content = `La base de données Corine Land Cover (CLC) est un outil précieux pour l'étude des revêtements de sol, car elle offre une cartographie détaillée des différentes classes d'occupation du sol à l'échelle européenne. En analysant ces données, il est possible d'identifier les types de revêtements, tels que les zones urbaines, agricoles, forestières ou les surfaces artificialisées, qui influencent la perméabilité des sols. Les zones urbaines et les surfaces artificielles, par exemple, sont souvent associées à une imperméabilisation accrue, réduisant l'infiltration de l'eau et favorisant le ruissellement. L'utilisation des données CLC permet ainsi d'évaluer l'impact des différents types de revêtements sur les processus hydrologiques et d'informer les politiques d'aménagement du territoire visant à préserver ou restaurer la perméabilité des sols.`;

                // Mettre à jour et afficher la boîte d'information
                addInfoToBox(content, title);
                var infoBox = document.getElementById('infoBox');
                infoBox.style.display = 'block';
            }

            // Toujours afficher un popup pour le polygone
            layer.bindPopup(" " + feature.properties.remark).openPopup();
        }
    });
}

// Appliquer les événements sur les couches GeoJSON
L.geoJson(CLC, {
    style: style,
    onEachFeature: onEachFeature
}).addTo(CLCLayer);



/* récupération d'une donnée linéaire : pistes cyclables */
var pistesCyclablesLayer = L.layerGroup();

fetch('https://data.grandlyon.com/geoserver/metropole-de-lyon/ows?SERVICE=WFS&VERSION=2.0.0&request=GetFeature&typename=metropole-de-lyon:pvo_patrimoine_voirie.pvoamenagementcyclable&outputFormat=application/json&SRSNAME=EPSG:4171&sortBy=gid')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        // Ajouter les pistes cyclables à la carte
        L.geoJson(data, {
            style: function () {
                return {
                    color: '#878787',
                    weight: 1,
                    opacity: 0.8,
                    dashArray: '5,5'
                };
            },
            onEachFeature: function (feature, layer) {
                if (feature.properties) {
                    layer.bindPopup(`<b>Type :</b> ${feature.properties.revetementpiste}`);
                }
            }
        }).addTo(pistesCyclablesLayer);
    })
    .catch(error => {
        console.error('Erreur lors du chargement des données GeoJSON :', error);
    });



// Ajouter directement les calques à la carte au démarrage pour que tout soit visible 
sitesPluieLayer.addTo(map);
CLCLayer.addTo(map);
pistesCyclablesLayer.addTo(map);


var overlayMaps = {
    "Sites de Pluviométrie": sitesPluieLayer,
    "Occupation du Sol (CLC)": CLCLayer,
    "Pistes Cyclables": pistesCyclablesLayer
};

L.control.layers(null, overlayMaps, { collapsed: false }).addTo(map);



// Fonction pour mettre à jour la légende en fonction des calques visibles
function updateLegend() {
    var content = '';

    // Vérifier si le calque "Sites de Pluviométrie" est visible. impossible la balise img à cause du logo du master aligné à droite (balise en html et style en css)
    if (map.hasLayer(sitesPluieLayer)) {
        content += `<i style="background-image: url('https://cdn-icons-png.flaticon.com/512/5611/5611083.png'); 
                                  background-size: contain; width: 20px; height: 20px; display: inline-block;"></i>
                        Site de pluviométrie<br>`;
    }

    // Vérifier si le calque "Pistes Cyclables" est visible
    if (map.hasLayer(pistesCyclablesLayer)) {
        content += `<i style="background:${'#878787'}; width: 20px; height: 2px; border: 1px solid #000; border-radius: 1px; display: inline-block;"></i> Pistes cyclables <br><br>`;
    }

    // Vérifier si le calque "Occupation du Sol (CLC)" est visible, si oui 
    if (map.hasLayer(CLCLayer)) {
        // Ajout un titre pour l'occupation du sol CLC
        content += '<b>Occupation du sol selon Corine Land Cover (CLC)</b><br>';
        // Et définition des catégories avec leurs étiquettes et couleurs
        var categories = [
            { label: 'Tissu urbain continu', color: '#E6004D' },
            { label: 'Tissu urbain discontinu', color: '#FF0000' },
            { label: 'Zones industrielles et commerciales', color: '#CC4DF2' },
            { label: 'Réseaux routier et ferroviaire et espaces associés', color: '#CC0000' },
            { label: 'Zones portuaires', color: '#E6CCCC' },
            { label: 'Aéroports', color: '#E6CCE6' },
            { label: 'Chantiers', color: '#D9D9D9' },
            { label: 'Extraction de matériaux', color: '#B2B2B2' },
            { label: 'Espaces verts urbains', color: '#33CC33' },
            { label: 'Prairies', color: '#99FF33' },
            { label: 'Landes et broussailles', color: '#A6FF80' },
            { label: 'Forêts de feuillus', color: '#80FF00' },
            { label: 'Vergers et petits fruits', color: '#FFB266' },
            { label: 'Systèmes culturaux et parcellaires complexes', color: '#FFD966' },
            { label: 'Surfaces essentiellement agricoles, interrompues par des espaces naturels importants', color: '#FFE699' },
            { label: 'Forêt et végétation arbustive en mutation', color: '#A6F200' },
            { label: 'Cours et voies d\'eau', color: '#00CCF2' },
            { label: 'Plans d\'eau', color: '#80F2E6' }
        ];
// Pour chaque catégorie, ajouter un petit carré coloré et le nom de la catégorie
        categories.forEach(function (category) {
            content += `<i style="background:${category.color}; width: 10px; height: 10px; border: 0.1px solid #000; border-radius: 1px; display: inline-block;"></i> ${category.label}<br>`;
        });
    }

    // Mettre à jour le contenu de la légende
    document.getElementById("legend-content").innerHTML = content;
}

// Légende selon la doc Leaflet
var legend = L.control({ position: 'bottomleft' }); 

// on a découvert cette fonction de Leaflet pour faciliter la stylisation de la légende avec la création d'une div utilisée ensuite dans le css
// + légende vide au début et qui se remplit dynamiquement 
legend.onAdd = function (map) {
    var div = L.DomUtil.create('div', 'info legend');
    div.innerHTML = '<div id="legend-content"></div>'; 
    return div;
};

legend.addTo(map);

// Initialiser la légende au démarrage pour que les calques par défaut soient pris en compte
updateLegend();

// Observer l'ajout ou la suppression de calques pour mettre à jour la légende
map.on('layeradd layerremove', updateLegend);



// On voulait offrir la possibilité pouvoir fermer la fenetre contextuelle d'informations sur les données polygonales et ponctuelles
/// au départ, le texte se multiplier autant de fois qu'on clique sur une entité, ce code permet de verifier que la fenetre n'est pas déjà affiché du coup

function addInfoToBox(content, title) {
    var infoBox = document.getElementById("infoBox");
    var contentElement = document.getElementById("infoBoxContent");
    var titleElement = document.getElementById("infoBoxTitle");
    var closeButton = document.getElementById("closeInfo");

    if (!contentElement) {
        contentElement = document.createElement("div");
        contentElement.id = "infoBoxContent";
        infoBox.appendChild(contentElement);
    }
    contentElement.innerHTML = content;

    if (!titleElement) {
        titleElement = document.createElement("div");
        titleElement.id = "infoBoxTitle";
        infoBox.insertBefore(titleElement, infoBox.firstChild);
    }
    titleElement.textContent = title;

    if (!closeButton) {
        closeButton = document.createElement("button");
        closeButton.id = "closeInfo";
        closeButton.textContent = "Fermer";
        infoBox.insertBefore(closeButton, titleElement.nextSibling);
    }

    closeButton.onclick = function () {
        infoBox.style.display = "none";
    };

    infoBox.style.display = "block";
}